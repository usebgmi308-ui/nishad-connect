// ─────────────────────────────────────────────────────────────
//  Firebase config  — Firebase Console → Project settings → Your apps → Web app
//  Agar aapka Realtime Database region alag hai (jaise Singapore), to
//  databaseURL wahi paste karein jo Console ke "Realtime Database" page par dikhta hai.
// ─────────────────────────────────────────────────────────────
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import {
  getAuth, signInAnonymously, signInWithEmailAndPassword, signOut, onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getDatabase } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-database.js";

export const firebaseConfig = {
  apiKey: "AIzaSyDRUWeHqggzp_k1HaZXlYTaQrrBnMlZCYY",
  authDomain: "nishadji-d1217.firebaseapp.com",
  databaseURL: "https://nishadji-d1217-default-rtdb.firebaseio.com",
  projectId: "nishadji-d1217"
};

export const OWNER_NAME = "Nishad";
export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getDatabase(app);
export { signInWithEmailAndPassword, signOut, onAuthStateChanged };

/** Visitor ke liye silent anonymous login (browser me yaad rehta hai). */
export async function ensureAnon() {
  await auth.authStateReady();
  if (auth.currentUser) return auth.currentUser;
  return (await signInAnonymously(auth)).user;
}
