import { db, ensureAnon, OWNER_NAME } from "./firebase.js";
import { ref, get, set, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-database.js";
import { mountChat, icon, toast } from "./chat-core.js";

const stage = document.getElementById("stage");
const match = location.pathname.match(/^\/chat\/([a-f0-9]{48})\/?$/i);
const token = match && match[1].toLowerCase();
const brand = `<div class="brand"><div class="logo">💬</div><div><b>Nishad Connect</b><small>Private conversation</small></div></div>`;

function loading() {
  stage.innerHTML = `<div class="center"><div class="spin big"></div><span>Opening secure chat…</span></div>`;
}
function stateCard(ic, title, text, bad = true, retry = false) {
  stage.innerHTML = `<div class="card glass">${brand}<div class="state-ic ${bad ? "bad" : ""}">${icon(ic)}</div><h1></h1><p class="lead"></p>${retry ? '<button class="btn primary">Try again</button>' : ""}</div>`;
  stage.querySelector("h1").textContent = title; stage.querySelector(".lead").textContent = text;
  if (retry) stage.querySelector(".btn").onclick = () => location.reload();
}
const denied = (e) => e && (e.code === "PERMISSION_DENIED" || /permission/i.test(e.message || ""));

async function main() {
  if (!token) return stateCard("off", "Invalid link", "This chat link looks incomplete or incorrect. Please ask for a fresh link.");
  loading();
  let user;
  try { user = await ensureAnon(); }
  catch { return stateCard("warn", "Setup incomplete", "Anonymous sign-in is not enabled for this project yet.", true, true); }
  let link, visitor = null, taken = false;
  try { link = (await get(ref(db, `links/${token}`))).val(); }
  catch { return stateCard("warn", "Connection problem", "Please check your internet connection and try again.", true, true); }
  if (!link) return stateCard("off", "Link not found", "This link doesn’t exist or was deleted by the owner.");
  try { visitor = (await get(ref(db, `visitors/${token}`))).val(); }
  catch (e) { if (denied(e)) taken = true; else return stateCard("warn", "Connection problem", "Please try again.", true, true); }
  if (taken) return stateCard("lock", "This link is private", "This conversation link has already been claimed by someone else, so it can’t be opened again.");
  if (visitor) return openChat(link, visitor, user, false);
  if (!link.active) return stateCard("pause2", "Link disabled", "The owner has switched this link off for now. Please try again later.");
  showJoin(link, user);
}

function showJoin(link, user) {
  const owner = link.ownerName || OWNER_NAME;
  stage.innerHTML = `<form class="card glass" novalidate>${brand}
    <h1>Chat with <span class="o"></span></h1>
    <p class="lead">Enter a few details to start a private, one-to-one conversation.</p>
    <div class="field"><input id="n" placeholder=" " maxlength="60" autocomplete="name" required><label for="n">Your name *</label></div>
    <div class="field"><input id="p" placeholder=" " maxlength="30" inputmode="tel" autocomplete="tel"><label for="p">Phone (optional)</label></div>
    <div class="field"><textarea id="t" rows="2" placeholder=" " maxlength="300"></textarea><label for="t">What is this about? (optional)</label></div>
    <button class="btn primary" type="submit">Start chatting ${icon("send")}</button>
    <div class="fine">${icon("lock")} This link works for one person only</div></form>`;
  stage.querySelector(".o").textContent = owner;
  const form = stage.querySelector("form"), n = form.querySelector("#n");
  setTimeout(() => n.focus(), 500);
  form.onsubmit = async (e) => {
    e.preventDefault();
    const name = n.value.trim();
    if (!name) { n.parentElement.classList.remove("err"); void n.offsetWidth; n.parentElement.classList.add("err"); return n.focus(); }
    const btn = form.querySelector(".btn"); btn.disabled = true; btn.innerHTML = '<div class="spin"></div>';
    const data = { uid: user.uid, name, joinedAt: serverTimestamp() };
    const ph = form.querySelector("#p").value.trim(), nt = form.querySelector("#t").value.trim();
    if (ph) data.phone = ph; if (nt) data.note = nt;
    try { await set(ref(db, `visitors/${token}`), data); }
    catch (err) {
      return denied(err) ? stateCard("lock", "Can’t join", "This link was just claimed by someone else, or the owner disabled it.")
                         : (toast("Something went wrong. Try again."), btn.disabled = false, btn.innerHTML = "Start chatting");
    }
    openChat(link, { name }, user, true);
  };
}

function openChat(link, visitor, user, animate) {
  const go = () => {
    stage.hidden = true; stage.innerHTML = "";
    const shell = document.createElement("div"); shell.className = "shell"; document.body.append(shell);
    mountChat({ root: shell, token, role: "visitor", uid: user.uid, title: link.ownerName || OWNER_NAME, subtitle: "Private chat" });
  };
  const card = stage.querySelector(".card");
  if (animate && card) { card.classList.add("leaving"); setTimeout(go, 420); } else go();
}
main();
