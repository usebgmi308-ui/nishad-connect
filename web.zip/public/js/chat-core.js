import { db } from "./firebase.js";
import {
  ref, push, set, get, onChildAdded, onChildChanged, onChildRemoved, onValue,
  onDisconnect, serverTimestamp, query, limitToLast
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-database.js";

export const MAX_FILE = 3 * 1024 * 1024; // 3 MB (free Realtime DB friendly)

/* ───────── tiny helpers ───────── */
const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
const P = {
  send: '<path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/>',
  clip: '<path d="m21.4 11-9.2 9.2a6 6 0 0 1-8.5-8.5l9.2-9.2a4 4 0 0 1 5.7 5.7l-9.2 9.2a2 2 0 0 1-2.8-2.8l8.5-8.5"/>',
  back: '<path d="m15 18-6-6 6-6"/>', down: '<path d="m6 9 6 6 6-6"/>', close: '<path d="M18 6 6 18M6 6l12 12"/>',
  dl: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
  file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/>',
  dots: '<circle cx="12" cy="5" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="12" cy="19" r="1.2"/>',
  check: '<path d="M20 6 9 17l-5-5"/>', dbl: '<path d="M18 6 7 17l-5-5M22 10l-7.5 7.5"/>', clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 16v-4M12 8h.01"/>', copy: '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/>', pause: '<path d="M10 4H6v16h4zM18 4h-4v16h4z"/>', play: '<path d="m6 3 14 9-14 9z"/>',
  reset: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8M3 3v5h5"/>', bolt: '<path d="m13 2-9 12h7l-1 8 9-12h-7z"/>',
  lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>', off: '<path d="M9 17H7a5 5 0 0 1 0-10h2M15 7h2a5 5 0 0 1 3.5 8.5M2 2l20 20"/>',
  warn: '<path d="m10.3 3.9-8.5 14.7A2 2 0 0 0 3.5 21.6h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0zM12 9v4M12 17h.01"/>',
  out: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>', plus: '<path d="M12 5v14M5 12h14"/>',
  chat: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>', pause2: '<path d="M10 4H6v16h4zM18 4h-4v16h4z"/>'
};
export const icon = (n) => `<svg class="ic" viewBox="0 0 24 24">${P[n] || ''}</svg>`;
export const initial = (s) => (s || "?").trim().charAt(0).toUpperCase() || "?";
export function avatarBg(name) {
  let h = 0; for (const c of name || "x") h = (h * 31 + c.charCodeAt(0)) % 360;
  return `linear-gradient(135deg,hsl(${h} 85% 62%),hsl(${(h + 45) % 360} 85% 55%))`;
}
const fmtTime = (t) => new Date(t).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
export const fmtShort = (t) => {
  const d = new Date(t), n = new Date();
  return d.toDateString() === n.toDateString() ? fmtTime(t) : d.toLocaleDateString([], { day: "numeric", month: "short" });
};
const dayLabel = (t) => {
  const d = new Date(t), n = new Date(), y = new Date(Date.now() - 864e5);
  if (d.toDateString() === n.toDateString()) return "Today";
  if (d.toDateString() === y.toDateString()) return "Yesterday";
  return d.toLocaleDateString([], { weekday: "short", day: "numeric", month: "short", year: "numeric" });
};
const fmtSize = (b) => b < 1024 ? b + " B" : b < 1048576 ? (b / 1024).toFixed(0) + " KB" : (b / 1048576).toFixed(1) + " MB";

export function toast(msg) {
  let box = document.querySelector(".toasts");
  if (!box) { box = el("div", "toasts"); document.body.append(box); }
  const t = el("div", "toast"); t.textContent = msg; box.append(t);
  setTimeout(() => { t.classList.add("out"); setTimeout(() => t.remove(), 320); }, 2600);
}
export async function copyText(text) {
  try { await navigator.clipboard.writeText(text); }
  catch { const t = el("textarea"); t.value = text; document.body.append(t); t.select(); document.execCommand("copy"); t.remove(); }
  toast("Copied ✓");
}
export function openModal(build) {
  const bg = el("div", "modal-bg"), m = el("div", "modal"); bg.append(m);
  const close = () => { bg.style.opacity = 0; setTimeout(() => bg.remove(), 200); };
  bg.addEventListener("click", (e) => { if (e.target === bg) close(); });
  build(m, close); document.body.append(bg); return close;
}
export function confirmDialog(title, text, okLabel = "Confirm", danger = true) {
  return new Promise((res) => openModal((m, close) => {
    m.innerHTML = `<h3></h3><p></p><div class="row"><button class="btn ghost" data-n>Cancel</button><button class="btn ${danger ? "danger" : "primary"}" data-y></button></div>`;
    m.querySelector("h3").textContent = title; m.querySelector("p").textContent = text; m.querySelector("[data-y]").textContent = okLabel;
    m.querySelector("[data-n]").onclick = () => { close(); res(false); };
    m.querySelector("[data-y]").onclick = () => { close(); res(true); };
  }));
}
export function openMenu(anchor, items) {
  document.querySelectorAll(".menu").forEach((x) => x.remove());
  const m = el("div", "menu");
  items.forEach((it) => {
    const b = el("button", it.danger ? "danger" : "", icon(it.icon || "dots") + "<span></span>");
    b.querySelector("span").textContent = it.label;
    b.onclick = () => { m.remove(); it.run(); }; m.append(b);
  });
  anchor.parentElement.append(m);
  const off = (e) => { if (!m.contains(e.target)) { m.remove(); document.removeEventListener("pointerdown", off, true); } };
  setTimeout(() => document.addEventListener("pointerdown", off, true), 0);
}
function linkify(p, text) {
  const re = /\bhttps?:\/\/[^\s<]+/gi; let last = 0, m;
  while ((m = re.exec(text))) {
    if (m.index > last) p.append(text.slice(last, m.index));
    const a = el("a"); a.href = m[0]; a.textContent = m[0]; a.target = "_blank"; a.rel = "noopener noreferrer"; p.append(a);
    last = m.index + m[0].length;
  }
  if (last < text.length) p.append(text.slice(last));
}
export function saveDataUrl(name, dataUrl) {
  if (window.NishadAndroid) { // Android WebView bridge
    const [h, b] = dataUrl.split(","); window.NishadAndroid.saveFile(name, h.slice(5).split(";")[0] || "application/octet-stream", b); return;
  }
  const a = el("a"); a.href = dataUrl; a.download = name; document.body.append(a); a.click(); a.remove();
}
const readAsDataURL = (f) => new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = no; r.readAsDataURL(f); });
async function prepImage(file) {
  const bmp = await createImageBitmap(file);
  const draw = (max, q) => {
    const s = Math.min(1, max / Math.max(bmp.width, bmp.height)), w = Math.round(bmp.width * s), h = Math.round(bmp.height * s);
    const c = document.createElement("canvas"); c.width = w; c.height = h; const x = c.getContext("2d");
    x.fillStyle = "#fff"; x.fillRect(0, 0, w, h); x.drawImage(bmp, 0, 0, w, h);
    return { url: c.toDataURL("image/jpeg", q), w, h };
  };
  let full = draw(1600, .82); if (full.url.length > 4.1e6) full = draw(1100, .65);
  let thumb = draw(320, .6); if (thumb.url.length > 28000) thumb = draw(200, .5);
  bmp.close && bmp.close();
  return { full: full.url, thumb: thumb.url, w: full.w, h: full.h };
}
const fileExt = (n) => (n.split(".").pop() || "").slice(0, 4).toUpperCase();

/* ═════════════════ the chat component ═════════════════ */
export function mountChat({ root, token, role, uid, title, subtitle = "", onBack }) {
  const peer = role === "owner" ? "visitor" : "owner";
  const base = `chats/${token}`;
  const unsubs = [];
  const els = new Map(), pending = new Set(), fileCache = new Map();
  let peerSeen = 0, peerOnline = false, peerTyping = false, locked = false, ready = false;
  let lastDay = "", lastFrom = "", lastTs = 0, unreadBelow = 0;

  root.innerHTML = "";
  const chat = el("section", "chat");
  chat.innerHTML = `
  <header class="c-head">
    <button class="icon-btn back" aria-label="Back">${icon("back")}</button>
    <div class="avatar"><span></span><i class="dot"></i></div>
    <div class="c-who"><b></b><small></small></div>
    <div class="c-actions"></div>
  </header>
  <div class="banner" hidden></div>
  <main class="c-body"><div class="c-list"></div></main>
  <button class="to-bottom" hidden aria-label="Latest">${icon("down")}<span></span></button>
  <footer class="composer">
    <button class="icon-btn attach" aria-label="Attach">${icon("clip")}</button>
    <div class="ta-wrap"><textarea rows="1" placeholder="Type a message" maxlength="3000"></textarea></div>
    <button class="send" disabled aria-label="Send">${icon("send")}</button>
    <input type="file" hidden multiple>
  </footer>
  <div class="drop">Drop files to send</div>`;
  root.append(chat);
  const $ = (s) => chat.querySelector(s);
  const body = $(".c-body"), list = $(".c-list"), ta = $("textarea"), sendBtn = $(".send"), fileIn = $("input[type=file]");
  const sub = $(".c-who small"), dot = $(".dot"), banner = $(".banner"), toBottom = $(".to-bottom"), composer = $(".composer");
  const avatar = $(".avatar");
  const api = {
    actions: $(".c-actions"),
    setTitle(t) { $(".c-who b").textContent = t; $(".avatar span").textContent = initial(t); avatar.style.background = avatarBg(t); },
    destroy
  };
  api.setTitle(title); sub.textContent = subtitle;
  if (onBack) $(".back").onclick = onBack; else $(".back").remove();

  /* ── status line ── */
  function refreshStatus() {
    dot.classList.toggle("on", peerOnline);
    sub.className = peerTyping ? "typ" : peerOnline ? "on" : "";
    if (peerTyping) sub.innerHTML = '<span class="typing-txt">typing<i>.</i><i>.</i><i>.</i></span>';
    else sub.textContent = peerOnline ? "Online" : (role === "owner" ? "Offline" : subtitle);
    syncTypingRow();
  }
  const typingRow = el("div", "typing-row", '<div class="typing-bub"><i></i><i></i><i></i></div>');
  function syncTypingRow() {
    const near = nearBottom();
    if (peerTyping && !typingRow.isConnected) { list.append(typingRow); if (near) scrollBottom(true); }
    else if (!peerTyping && typingRow.isConnected) typingRow.remove();
  }

  /* ── scrolling ── */
  const nearBottom = () => body.scrollHeight - body.scrollTop - body.clientHeight < 140;
  const scrollBottom = (smooth) => body.scrollTo({ top: body.scrollHeight, behavior: smooth ? "smooth" : "auto" });
  body.addEventListener("scroll", () => {
    const n = nearBottom(); toBottom.hidden = n; if (n) { unreadBelow = 0; toBottom.querySelector("span").textContent = ""; }
  }, { passive: true });
  toBottom.onclick = () => scrollBottom(true);

  /* ── ticks ── */
  const tickHTML = (s) => s === "pending" ? icon("clock") : s === "seen" ? icon("dbl") : icon("check");
  function updateTick(id) {
    const r = els.get(id); if (!r || !r.mine) return;
    const st = pending.has(id) ? "pending" : (r.m.ts <= peerSeen ? "seen" : "sent");
    if (r.state !== st) { r.state = st; r.tick.className = "ticks " + st; r.tick.innerHTML = tickHTML(st); }
  }

  /* ── rendering ── */
  function insertNode(node) { typingRow.isConnected ? list.insertBefore(node, typingRow) : list.append(node); }
  function buildMsg(id, m, fresh) {
    const mine = m.from === role;
    const same = lastFrom === m.from && m.ts - lastTs < 180000 && dayStr(m.ts) === lastDay;
    const day = dayStr(m.ts);
    if (day !== lastDay) { const s = el("div", "sep"); s.textContent = dayLabel(m.ts); insertNode(s); lastDay = day; }
    lastFrom = m.from; lastTs = m.ts;
    const row = el("div", `msg ${mine ? "me" : "them"}${same ? " cont" : ""}${fresh ? " fresh" : ""}`);
    const b = el("div", "bubble");
    if (m.type === "image") {
      b.classList.add("has-img");
      const w = el("div", "img-wrap"); w.style.aspectRatio = `${m.w || 4}/${m.h || 3}`;
      const img = new Image(); img.src = m.thumb; img.alt = m.name || "photo"; w.append(img);
      w.onclick = () => openLightbox(m); b.append(w);
    } else if (m.type === "file") {
      const c = el("div", "filecard", `<div class="fi">${icon("file")}</div><div class="fn"><b></b><small></small></div><div class="dl">${icon("dl")}</div>`);
      c.querySelector("b").textContent = m.name || "file";
      c.querySelector("small").textContent = `${fileExt(m.name || "")} · ${fmtSize(m.size || 0)}`;
      c.onclick = async () => {
        const d = c.querySelector(".dl"); d.innerHTML = '<div class="spin"></div>';
        try { saveDataUrl(m.name || "file", await loadFile(m.fileId)); } catch { toast("Download failed"); }
        d.innerHTML = icon("dl");
      };
      b.append(c);
    }
    if (m.text) { const p = el("p", "txt"); linkify(p, m.text); b.append(p); }
    const meta = el("div", "meta"); const tm = el("span"); tm.textContent = fmtTime(m.ts); meta.append(tm);
    let tick = null;
    if (mine) { tick = el("span", "ticks"); meta.append(tick); }
    b.append(meta); row.append(b);
    els.set(id, { row, m, mine, tick, state: "" });
    insertNode(row); updateTick(id);
    return row;
  }
  const dayStr = (t) => new Date(t).toDateString();
  const emptyEl = el("div", "empty", '<div class="wave">👋</div><p>Say hello — this is a private<br>one-to-one conversation.</p>');
  list.append(emptyEl);

  async function loadFile(fid) {
    if (fileCache.has(fid)) return fileCache.get(fid);
    const v = (await get(ref(db, `${base}/files/${fid}`))).val();
    if (!v) throw new Error("missing"); fileCache.set(fid, v); return v;
  }

  /* ── lightbox ── */
  let lb = null;
  function openLightbox(m) {
    if (!lb) {
      lb = el("div", "lb", `<div class="bar"><button class="s" aria-label="Save">${icon("dl")}</button><button class="x" aria-label="Close">${icon("close")}</button></div><img><div class="cap"></div>`);
      lb.hidden = true; document.body.append(lb);
      lb.addEventListener("click", (e) => { if (e.target === lb || e.target.closest(".x")) lb.hidden = true; });
      document.addEventListener("keydown", escClose);
    }
    const img = lb.querySelector("img"); img.src = m.thumb; img.classList.add("blur");
    lb.querySelector(".cap").textContent = m.name || ""; lb.hidden = false;
    let full = null;
    loadFile(m.fileId).then((u) => { full = u; img.src = u; img.classList.remove("blur"); }).catch(() => toast("Could not load photo"));
    lb.querySelector(".s").onclick = () => full ? saveDataUrl(m.name || "photo.jpg", full) : toast("Still loading…");
  }
  const escClose = (e) => { if (e.key === "Escape" && lb) lb.hidden = true; };

  /* ── sending ── */
  async function sendMessage(payload) {
    const r = push(ref(db, `${base}/messages`)); pending.add(r.key);
    try { await set(r, { from: role, uid, ts: serverTimestamp(), ...payload }); }
    catch { toast("Could not send. Link may be disabled."); }
    finally { pending.delete(r.key); updateTick(r.key); }
  }
  function sendText() {
    const text = ta.value.trim(); if (!text || locked) return;
    ta.value = ""; autosize(); sendBtn.disabled = true; setTyping(false);
    sendMessage({ type: "text", text }); ta.focus();
  }
  async function sendFiles(files) {
    for (const f of files) {
      if (locked) return;
      if (f.size > MAX_FILE * 8) { toast(`${f.name}: too large`); continue; }
      try {
        if (f.type.startsWith("image/") && f.type !== "image/svg+xml") {
          let prep; try { prep = await prepImage(f); } catch { prep = null; }
          if (prep) { await sendImage(f, prep); continue; }
        }
        if (f.size > MAX_FILE) { toast(`${f.name}: max file size is 3 MB`); continue; }
        const data = await readAsDataURL(f);
        const fid = push(ref(db, `${base}/files`)).key;
        const tmp = placeholder(null); await set(ref(db, `${base}/files/${fid}`), data);
        const p = sendMessage({ type: "file", fileId: fid, name: f.name.slice(0, 200), size: f.size, mime: (f.type || "application/octet-stream").slice(0, 100) });
        tmp.remove(); await p;
      } catch { toast("Upload failed"); }
    }
  }
  function placeholder(thumb) {
    const row = el("div", "msg me up fresh"), b = el("div", "bubble" + (thumb ? " has-img" : ""));
    if (thumb) { const w = el("div", "img-wrap"); const i = new Image(); i.src = thumb; w.append(i); b.append(w); }
    else b.innerHTML = '<div class="filecard"><div class="fi"><div class="spin"></div></div><div class="fn"><b>Uploading…</b></div></div>';
    row.append(b); emptyEl.remove(); insertNode(row); scrollBottom(true); return row;
  }
  async function sendImage(f, prep) {
    const fid = push(ref(db, `${base}/files`)).key, tmp = placeholder(prep.thumb);
    try {
      await set(ref(db, `${base}/files/${fid}`), prep.full); fileCache.set(fid, prep.full);
      const p = sendMessage({ type: "image", fileId: fid, thumb: prep.thumb, w: prep.w, h: prep.h, name: (f.name || "photo.jpg").slice(0, 200), size: f.size, mime: "image/jpeg" });
      tmp.remove(); await p;
    } catch (e) { tmp.remove(); throw e; }
  }

  /* ── composer events ── */
  const coarse = matchMedia("(pointer:coarse)").matches;
  function autosize() { ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, 140) + "px"; }
  let tTimer, tOn = false;
  function setTyping(on) { if (on === tOn) return; tOn = on; set(ref(db, `${base}/typing/${role}`), on ? true : null).catch(() => {}); }
  ta.addEventListener("input", () => {
    autosize(); sendBtn.disabled = !ta.value.trim();
    if (ta.value.trim()) { setTyping(true); clearTimeout(tTimer); tTimer = setTimeout(() => setTyping(false), 2500); } else setTyping(false);
  });
  ta.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey && !coarse) { e.preventDefault(); sendText(); } });
  ta.addEventListener("paste", (e) => { const fs = e.clipboardData && e.clipboardData.files; if (fs && fs.length) { e.preventDefault(); sendFiles([...fs]); } });
  ta.addEventListener("focus", () => setTimeout(() => scrollBottom(true), 300));
  sendBtn.onclick = sendText;
  $(".attach").onclick = () => fileIn.click();
  fileIn.onchange = () => { sendFiles([...fileIn.files]); fileIn.value = ""; };
  const drop = $(".drop"); let dc = 0;
  chat.addEventListener("dragenter", (e) => { e.preventDefault(); dc++; drop.classList.add("on"); });
  chat.addEventListener("dragleave", () => { if (--dc <= 0) { dc = 0; drop.classList.remove("on"); } });
  chat.addEventListener("dragover", (e) => e.preventDefault());
  chat.addEventListener("drop", (e) => { e.preventDefault(); dc = 0; drop.classList.remove("on"); if (e.dataTransfer.files.length) sendFiles([...e.dataTransfer.files]); });

  /* ── seen ── */
  let sTimer;
  function markSeen() {
    if (document.visibilityState !== "visible") return;
    clearTimeout(sTimer); sTimer = setTimeout(() => set(ref(db, `${base}/seen/${role}`), serverTimestamp()).catch(() => {}), 250);
  }
  const onVis = () => { markSeen(); };
  document.addEventListener("visibilitychange", onVis);

  /* ── live listeners ── */
  const q = query(ref(db, `${base}/messages`), limitToLast(300));
  (async () => {
    try {
      const snap = await get(q); const frag = [];
      snap.forEach((c) => { frag.push([c.key, c.val()]); });
      if (frag.length) emptyEl.remove();
      frag.forEach(([k, m]) => buildMsg(k, m, false));
      scrollBottom(false); ready = true; markSeen();
    } catch { banner.hidden = false; banner.textContent = "Cannot open this conversation."; ready = true; }
    unsubs.push(onChildAdded(q, (s) => {
      if (els.has(s.key)) return; const m = s.val(); emptyEl.remove();
      const near = nearBottom(); buildMsg(s.key, m, true);
      if (m.from === role || near) scrollBottom(true);
      else { unreadBelow++; toBottom.hidden = false; toBottom.querySelector("span").textContent = unreadBelow; }
      if (m.from !== role) markSeen();
    }));
    unsubs.push(onChildChanged(q, (s) => { const r = els.get(s.key); if (r) { r.m = s.val(); updateTick(s.key); } }));
    unsubs.push(onChildRemoved(q, (s) => { const r = els.get(s.key); if (r) { r.row.remove(); els.delete(s.key); } }));
  })();
  unsubs.push(onValue(ref(db, `${base}/seen/${peer}`), (s) => { peerSeen = s.val() || 0; els.forEach((_, id) => updateTick(id)); }));
  unsubs.push(onValue(ref(db, `${base}/typing/${peer}`), (s) => { peerTyping = !!s.val(); refreshStatus(); }));
  unsubs.push(onValue(ref(db, `${base}/presence/${peer}`), (s) => { peerOnline = !!s.val(); refreshStatus(); }));
  unsubs.push(onValue(ref(db, `links/${token}/active`), (s) => {
    locked = s.val() === false;
    composer.classList.toggle("locked", locked); banner.hidden = !locked;
    banner.textContent = role === "owner" ? "This link is disabled — the visitor can’t send messages." : "This chat has been paused by the owner.";
  }));
  const pr = ref(db, `${base}/presence/${role}`), ty = ref(db, `${base}/typing/${role}`);
  unsubs.push(onValue(ref(db, ".info/connected"), (s) => {
    if (!s.val()) return;
    onDisconnect(pr).remove().then(() => set(pr, true)).catch(() => {});
    onDisconnect(ty).remove().catch(() => {});
  }));
  refreshStatus();

  function destroy() {
    unsubs.forEach((u) => { try { u(); } catch {} });
    document.removeEventListener("visibilitychange", onVis); document.removeEventListener("keydown", escClose);
    set(pr, null).catch(() => {}); set(ty, null).catch(() => {});
    clearTimeout(tTimer); clearTimeout(sTimer);
    if (lb) lb.remove(); root.innerHTML = "";
  }
  return api;
}
