import { auth, db, OWNER_NAME, signInWithEmailAndPassword, signOut, onAuthStateChanged } from "./firebase.js";
import {
  ref, set, update, remove, onValue, query, orderByChild, equalTo, limitToLast, onChildAdded
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-database.js";
import {
  mountChat, icon, toast, copyText, openMenu, openModal, confirmDialog, avatarBg, initial, fmtShort
} from "./chat-core.js";

const loginEl = document.getElementById("login"), appEl = document.getElementById("app");
const brand = `<div class="brand"><div class="logo">💬</div><div><b>Nishad Connect</b><small>Owner panel</small></div></div>`;
const SITE = location.origin;
const linkUrl = (t) => `${SITE}/chat/${t}`;

let me = null, chat = null, current = null, linksUnsub = null;
const links = new Map(), visitors = new Map(), lastMsg = new Map(), seenOwner = new Map(), watchers = new Map();

/* ───────── login ───────── */
function showLogin() {
  teardown(); appEl.hidden = true; loginEl.hidden = false;
  loginEl.innerHTML = `<form class="card glass" novalidate>${brand}
    <h1>Welcome back</h1><p class="lead">Sign in to manage your private chats.</p>
    <div class="field"><input id="e" type="email" placeholder=" " autocomplete="username"><label for="e">Owner email</label></div>
    <div class="field"><input id="p" type="password" placeholder=" " autocomplete="current-password"><label for="p">Password</label></div>
    <button class="btn primary" type="submit">Sign in</button></form>`;
  const f = loginEl.querySelector("form");
  f.onsubmit = async (ev) => {
    ev.preventDefault();
    const em = f.querySelector("#e").value.trim(), pw = f.querySelector("#p").value;
    if (!em || !pw) return toast("Enter email and password");
    const b = f.querySelector(".btn"); b.disabled = true; b.innerHTML = '<div class="spin"></div>';
    try { await signInWithEmailAndPassword(auth, em, pw); }
    catch { toast("Login failed — check email & password"); b.disabled = false; b.textContent = "Sign in"; }
  };
}
onAuthStateChanged(auth, (u) => {
  if (u && !u.isAnonymous) { me = u; loginEl.hidden = true; showApp(); } else { me = null; showLogin(); }
});

/* ───────── app shell ───────── */
function showApp() {
  appEl.hidden = false;
  appEl.innerHTML = `
  <aside class="side">
    <div class="side-h">${brand}
      <button class="icon-btn" id="newlink" title="New link">${icon("plus")}</button>
      <button class="icon-btn" id="logout" title="Sign out">${icon("out")}</button></div>
    <ul class="list" id="list"></ul>
  </aside>
  <section class="pane" id="pane"></section>`;
  appEl.querySelector("#newlink").onclick = newLink;
  appEl.querySelector("#logout").onclick = async () => { if (await confirmDialog("Sign out?", "You will need to log in again.", "Sign out", false)) signOut(auth); };
  paneEmpty();
  linksUnsub = onValue(query(ref(db, "links"), orderByChild("ownerUid"), equalTo(me.uid)), (snap) => {
    const seen = new Set();
    snap.forEach((c) => { seen.add(c.key); links.set(c.key, c.val()); watch(c.key); });
    [...links.keys()].forEach((k) => { if (!seen.has(k)) { links.delete(k); unwatch(k); if (current === k) closeChat(); } });
    renderList();
  }, () => toast("Could not load chats — check database rules"));
}
function teardown() {
  if (linksUnsub) linksUnsub(); linksUnsub = null;
  [...watchers.keys()].forEach(unwatch); links.clear(); visitors.clear(); lastMsg.clear(); seenOwner.clear();
  if (chat) chat.destroy(); chat = null; current = null;
}

/* ───────── per-link live watchers ───────── */
function watch(t) {
  if (watchers.has(t)) return;
  const u = [];
  u.push(onValue(ref(db, `visitors/${t}`), (s) => { s.exists() ? visitors.set(t, s.val()) : visitors.delete(t); renderList(); if (current === t) openChat(t, true); }));
  u.push(onChildAdded(query(ref(db, `chats/${t}/messages`), limitToLast(1)), (s) => { lastMsg.set(t, s.val()); renderList(); }));
  u.push(onValue(ref(db, `chats/${t}/seen/owner`), (s) => { seenOwner.set(t, s.val() || 0); renderList(); }));
  watchers.set(t, u);
}
function unwatch(t) { (watchers.get(t) || []).forEach((f) => f()); watchers.delete(t); visitors.delete(t); lastMsg.delete(t); seenOwner.delete(t); }

/* ───────── list ───────── */
let raf = 0;
function renderList() { cancelAnimationFrame(raf); raf = requestAnimationFrame(drawList); }
function drawList() {
  const ul = document.getElementById("list"); if (!ul) return;
  const rows = [...links.entries()].map(([t, l]) => {
    const v = visitors.get(t), lm = lastMsg.get(t);
    return { t, l, v, lm, ts: (lm && lm.ts) || (v && v.joinedAt) || l.createdAt || 0 };
  }).sort((a, b) => b.ts - a.ts);
  ul.innerHTML = "";
  if (!rows.length) {
    ul.innerHTML = `<div class="empty"><div class="wave">🔗</div><p>No chats yet.<br>Tap <b>+</b> to create a private link<br>and share it.</p></div>`; return;
  }
  rows.forEach(({ t, l, v, lm }, i) => {
    const unread = lm && lm.from === "visitor" && lm.ts > (seenOwner.get(t) || 0) && current !== t;
    const name = v ? v.name : "Unclaimed link";
    const b = document.createElement("button");
    b.className = "item" + (current === t ? " sel" : "") + (unread ? " unread" : "");
    b.style.animationDelay = Math.min(i * 40, 300) + "ms";
    b.innerHTML = `<div class="avatar"><span></span></div><div class="mid"><b></b><small></small></div><div class="end"><span class="tm"></span><span class="st"></span></div>`;
    const av = b.querySelector(".avatar"); av.style.background = v ? avatarBg(name) : "linear-gradient(135deg,#475569,#334155)";
    av.querySelector("span").textContent = v ? initial(name) : "🔗";
    b.querySelector("b").textContent = name;
    b.querySelector("small").textContent = lm ? (lm.from === "owner" ? "You: " : "") + (lm.type === "image" ? "📷 Photo" : lm.type === "file" ? "📎 " + (lm.name || "File") : lm.text) : v ? (v.note || "Joined — no messages yet") : "Waiting for someone to open…";
    const tm = b.querySelector(".tm"); tm.textContent = lm ? fmtShort(lm.ts) : "";
    const st = b.querySelector(".st");
    if (unread) st.innerHTML = '<span class="badge">●</span>';
    else if (l.active === false) st.innerHTML = '<span class="chip">Disabled</span>';
    else if (!v) st.innerHTML = '<span class="chip wait">Waiting</span>';
    b.onclick = () => openChat(t);
    ul.append(b);
  });
}

/* ───────── opening a chat ───────── */
function paneEmpty() {
  const p = document.getElementById("pane"); if (!p) return;
  p.innerHTML = `<div class="pane-empty"><div class="state-ic">${icon("chat")}</div><h2>Select a conversation</h2><p>Pick a chat on the left, or create a new private link with the + button.</p></div>`;
}
function closeChat() {
  if (chat) chat.destroy(); chat = null; current = null;
  appEl.classList.remove("show-chat"); paneEmpty(); renderList();
}
window.__back = () => { if (appEl.classList.contains("show-chat")) { closeChat(); return true; } return false; };

function openChat(t, refresh = false) {
  const l = links.get(t), v = visitors.get(t); if (!l) return;
  if (!refresh || !chat) {
    if (chat) chat.destroy(); chat = null; current = t;
    appEl.classList.add("show-chat"); renderList();
  }
  const pane = document.getElementById("pane");
  if (!v) { // unclaimed
    if (chat) { chat.destroy(); chat = null; }
    pane.innerHTML = `<header class="c-head"><button class="icon-btn back">${icon("back")}</button><b style="flex:1">Private link</b></header>
      <div class="pane-empty"><div class="state-ic">${icon("lock")}</div><h2>Waiting for a visitor</h2><p>Share this link with one person. The first person who opens it and enters their name gets locked in.</p>
      <div class="linkbox"></div><button class="btn primary" id="cp">${icon("copy")} Copy link</button><div style="height:10px"></div><button class="btn ghost" id="sh">Share…</button><div style="height:10px"></div><button class="btn ghost" id="dl">Delete link</button></div>`;
    pane.querySelector(".back").onclick = closeChat;
    pane.querySelector(".linkbox").textContent = linkUrl(t);
    pane.querySelector("#cp").onclick = () => copyText(linkUrl(t));
    pane.querySelector("#sh").onclick = () => shareLink(t);
    pane.querySelector("#dl").onclick = () => deleteAll(t);
    return;
  }
  if (chat && refresh) { chat.setTitle(v.name); return; }
  chat = mountChat({ root: pane, token: t, role: "owner", uid: me.uid, title: v.name, subtitle: "Offline", onBack: closeChat });
  const more = document.createElement("button"); more.className = "icon-btn"; more.innerHTML = icon("dots"); more.setAttribute("aria-label", "More");
  chat.actions.append(more);
  more.onclick = () => openMenu(more, [
    { label: "Visitor details", icon: "info", run: () => details(t) },
    { label: "Copy link", icon: "copy", run: () => copyText(linkUrl(t)) },
    { label: links.get(t).active === false ? "Enable link" : "Disable link", icon: links.get(t).active === false ? "play" : "pause", run: () => toggle(t) },
    { label: "Reset (allow new visitor)", icon: "reset", run: () => reset(t) },
    { label: "Delete conversation", icon: "trash", danger: true, run: () => deleteAll(t) }
  ]);
}

/* ───────── actions ───────── */
function token48() { const a = new Uint8Array(24); crypto.getRandomValues(a); return [...a].map((x) => x.toString(16).padStart(2, "0")).join(""); }
async function newLink() {
  const t = token48();
  try {
    await set(ref(db, `links/${t}`), { ownerUid: me.uid, ownerName: OWNER_NAME, active: true, createdAt: Date.now() });
    await copyText(linkUrl(t)); toast("New private link created & copied"); setTimeout(() => openChat(t), 400);
  } catch { toast("Could not create link"); }
}
async function shareLink(t) { if (navigator.share) { try { await navigator.share({ title: "Nishad Connect", text: "Join my private chat", url: linkUrl(t) }); } catch {} } else copyText(linkUrl(t)); }
async function toggle(t) {
  const on = links.get(t).active === false;
  try { await update(ref(db, `links/${t}`), { active: on }); toast(on ? "Link enabled" : "Link disabled"); } catch { toast("Failed"); }
}
async function reset(t) {
  if (!await confirmDialog("Reset this link?", "The current visitor will be removed and ALL messages deleted. The next person who opens the link can join.", "Reset")) return;
  try { await remove(ref(db, `chats/${t}`)); await remove(ref(db, `visitors/${t}`)); lastMsg.delete(t); toast("Link reset"); closeChat(); } catch { toast("Failed"); }
}
async function deleteAll(t) {
  if (!await confirmDialog("Delete permanently?", "The link, visitor and every message & file will be erased.", "Delete")) return;
  try {
    await remove(ref(db, `chats/${t}`)); await remove(ref(db, `visitors/${t}`)); await remove(ref(db, `links/${t}`));
    toast("Deleted"); if (current === t) closeChat();
  } catch { toast("Failed"); }
}
function details(t) {
  const v = visitors.get(t); if (!v) return;
  openModal((m, close) => {
    m.innerHTML = `<h3>Visitor details</h3><div class="kv"></div><button class="btn ghost">Close</button>`;
    const kv = m.querySelector(".kv");
    [["Name", v.name], ["Phone", v.phone || "—"], ["Note", v.note || "—"], ["Joined", v.joinedAt ? new Date(v.joinedAt).toLocaleString() : "—"]].forEach(([k, val]) => {
      const d = document.createElement("div"); d.innerHTML = "<small></small><span></span>"; d.children[0].textContent = k; d.children[1].textContent = val; kv.append(d);
    });
    m.querySelector(".btn").onclick = close;
  });
}
